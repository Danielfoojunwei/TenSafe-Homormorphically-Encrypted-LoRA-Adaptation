from .spec import VERSION

__all__ = ["VERSION"]
