"""TenSafe API Playground package."""

from .routes import router

__all__ = ["router"]
