"""
TensorGuard Management Platform
"""
