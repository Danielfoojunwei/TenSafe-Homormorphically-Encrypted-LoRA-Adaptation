"""TG-Tinker vs Baseline comparison benchmarks."""
